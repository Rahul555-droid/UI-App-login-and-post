import Login from './LoginPage';
function App() {
  return (
    <>
    <Login />
    </>
  );
}

export default App;
